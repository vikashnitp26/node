package com.aniket.nodes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NodesApplicationTests {

	@Test
	void contextLoads() {
	}

}
