package com.aniket.nodes.model;

import java.util.HashSet;
import java.util.Objects;

import org.springframework.context.annotation.Scope;
import org.springframework.web.context.WebApplicationContext;

import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Scope(value=WebApplicationContext.SCOPE_APPLICATION)
public class Node {
	@NonNull
	public Integer data;
	public HashSet<Node> nodes = new HashSet<>();

	@Override
	public int hashCode() {
		return Objects.hash(data);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Node other = (Node) obj;
		return Objects.equals(data, other.data);
	}

	@Override
	public String toString() {
		return "Node [data=" + data + "]";
	}

}
