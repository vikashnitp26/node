package com.aniket.nodes.service;

import java.util.HashSet;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.web.context.WebApplicationContext;

import com.aniket.nodes.model.Node;

@Service
@Scope(value = WebApplicationContext.SCOPE_APPLICATION)
public class NodeService {

	private static HashSet<Node> startNodes = new HashSet<Node>();
	private Node nodeG ;
	public void add(Node n1, Node n2) {
		Node node1=null,node2=null;
		if(findNode(startNodes, n1)) {
			node1 = nodeG;
		}
		if(findNode(startNodes, n2)) {
			node2 = nodeG;
		}
		if (node1 == null && node2 == null) {
			startNodes.add(n1);
			n1.nodes.add(n2);
		} else if (node1 == null) {
			startNodes.add(n1);
			n1.nodes.add(node2);
		} else if (node2 == null) {
			node1.nodes.add(n2);
		}

	}

	public boolean findNode(HashSet<Node> tempNodes, Node n) {
		if (tempNodes == null || tempNodes.isEmpty()) {
			return false;
		}
		boolean isFound = false;
		for (Node temp : tempNodes) {
			if (temp.equals(n)) {
				//System.out.println(temp);
				this.nodeG = temp;
				return true;
			} 
			isFound = isFound || findNode(temp.nodes, n);
		}
		
		return isFound;
	}

	public boolean isConnected(Node n1, Node n2) {
		//System.out.println("startNodes::" + startNodes);
		Node node1 = null;
		if(findNode(startNodes, n1)) {
			node1 = nodeG;
		}
		if (node1 != null) {
			if (findNode(node1.nodes, n2)) {
				return true;
			}
		}
		return false;
	}

//	public static void main(String[] args) {
//		NodeService nodeService = new NodeService();
//		nodeService.add(new Node(2), new Node(3));
//		nodeService.add(new Node(2), new Node(4));
////		nodeService.add(new Node(4), new Node(5));
////		nodeService.add(new Node(7), new Node(8));
//		System.out.println(nodeService.isConnected(new Node(2), new Node(4)));
//		//System.out.println(nodeService.findNode(startNodes, new Node(2)));
//
//	}
}
