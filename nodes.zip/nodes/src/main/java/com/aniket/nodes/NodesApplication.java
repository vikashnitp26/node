package com.aniket.nodes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NodesApplication {

	public static void main(String[] args) {
		SpringApplication.run(NodesApplication.class, args);
	}

}
