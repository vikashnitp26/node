package com.aniket.nodes.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.aniket.nodes.model.Node;
import com.aniket.nodes.service.NodeService;

@RestController
public class NodeController {

	@Autowired
	NodeService nodeService;

	@PostMapping("/")
	public String addNode(@RequestParam int n1, @RequestParam int n2) {
		nodeService.add(new Node(n1), new Node(n2));
		return "added";
	}
	
	@GetMapping("/")
	public Boolean isConnected(@RequestParam int n1, @RequestParam int n2) {
		return nodeService.isConnected(new Node(n1), new Node(n2));
	}
}
